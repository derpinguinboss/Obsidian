export const en = {
	'Default:': 'Default:',
	'Error:': 'Error:',
	'missing default light value, or value is not in a valid color format':
		'missing default light value, or value is not in a valid color format',
	'missing default dark value, or value is not in a valid color format':
		'missing default dark value, or value is not in a valid color format',
	'missing default value, or value is not in a valid color format':
		'missing default value, or value is not in a valid color format',
	'missing default value': 'missing default value',
};
