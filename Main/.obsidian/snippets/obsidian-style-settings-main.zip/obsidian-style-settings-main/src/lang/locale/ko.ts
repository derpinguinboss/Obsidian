export const ko = {};
