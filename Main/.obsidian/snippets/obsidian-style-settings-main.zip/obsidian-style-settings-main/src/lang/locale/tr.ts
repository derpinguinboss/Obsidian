export const tr = {};
