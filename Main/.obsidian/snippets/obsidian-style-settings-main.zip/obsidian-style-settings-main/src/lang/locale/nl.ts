export const nl = {
	'Default:': 'Standaard:',
	'Error:': 'Error:',
	'missing default light value, or value is not in a valid color format':
		'Geen standaard waarde voor het lichte thema, of de waarde is niet in het goede formaat',
	'missing default dark value, or value is not in a valid color format':
		'Geen standaard waarde voor het donkere thema, of de waarde is niet in het goede formaat',
	'missing default value, or value is not in a valid color format':
		'Geen standaard waarde, of de waarde is niet in het goede formaat',
	'missing default value': 'Geen standaard waarde',
};
