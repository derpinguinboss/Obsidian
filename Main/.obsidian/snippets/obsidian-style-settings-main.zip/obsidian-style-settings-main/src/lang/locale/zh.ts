export const zh = {
	'Default:': '默认：',
	'Error:': '错误：',
	'missing default light value, or value is not in a valid color format':
		'缺少默认的浅色模式色值，或该色值没有采用一个有效的颜色格式',
	'missing default dark value, or value is not in a valid color format':
		'缺少默认的深色模式色值，或该色值没有采用一个有效的颜色格式',
	'missing default value, or value is not in a valid color format':
		'缺少默认色值，或该色值没有采用一个有效的颜色格式',
	'missing default value': '缺少默认色值',
};
