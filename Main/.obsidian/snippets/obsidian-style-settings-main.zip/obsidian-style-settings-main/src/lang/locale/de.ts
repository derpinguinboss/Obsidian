export const de = {
	'Default:': 'Standard:',
	'Error:': 'Fehler:',
	'missing default light value, or value is not in a valid color format':
		'Fehlender heller standard Wert oder Wert ist in keinem validen Farb-Format',
	'missing default dark value, or value is not in a valid color format':
		'Fehlender dunkler standard Wert oder Wert ist in keinem validen Farb-Format',
	'missing default value, or value is not in a valid color format':
		'Fehlender standard Wert oder Wert ist in keinem validen Farb-Format',
	'missing default value': 'Fehlender standard Wert',
};
