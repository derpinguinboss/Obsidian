
Definition
---
- Funktionale Organisationen für einzelne Sektoren 
- Geographische Regionen verlieren an Bedeutung
	- (-> kommen aus der Funktion die sie erfuellen)
