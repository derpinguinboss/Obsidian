Src
---
[D:/Schule/Sowi/eu/Handout%20EU%20Kommission%20pdf.pdf](file:///D:/Schule/Sowi/eu/Handout%20EU%20Kommission%20pdf.pdf)
[72061](https://www.ccbuchner.de/_files_media/livebook/5782/)


Definition
---
- EU-Kommission übernimmt Funktionen einer Regierung 
- dazu gehören exekutive Aufgaben 
- vertritt Interessen der Europäischen Union, nicht die Interessen eines bestimmten Mitgliedstaates 
- Gründung: 16. Januar 1958 
- Vorsitz: Ursula von der Leyen (Kommissionspräsidentin) -> fraktionsunabhängig 
- durch Knappheit gewonnen 
- Hauptsitz: Berlaymont-Gebäude, Brüssel, Belgien


Aufgaben
---
- Überwachung der EU-Verträge
- Motor der EU-Integration
- Initiativrecht für "EU-Gesetze"


Zusammensetzung
---
- 27 Kommissare
- Präsidentin der Kommission
- Hoher Vertreter für Außen- und Sicherheitspolitik der EU


Legitimation
---
EU-Kommissionspräsidenten schlägt EU-Kommissare vor, [[Europäisches Parlament]] wählt (Bestätigung und Abwahl nur als Ganzes möglich).
