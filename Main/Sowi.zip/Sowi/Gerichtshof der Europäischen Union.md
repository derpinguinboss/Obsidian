
Aufgaben
---
Wahrung des EU-Rechts bei der Auslegung und Anwendung der Verträge der Europäischen Union.

Zusammensetzung 
---
- [[EuGH]]: je Mitgliedsland ein Richter
- [[EuG]]: je Mitgliedsland ein Richter
- [[Fachgericht]]: 7 Richter

Legitimation
---
Ernennung der Regierungen der Mitgliedsländer ([[Europäischer Rat]]).