
Vokabeln
---

EGKS - [[Europäische Gemeinschaft für Kohle und Stahl]]

Sechs Gründerstaaten - Deutschland, Frankreich, Italien, [[Benelux]]

EVG - [[Europäische Verteidigungsgemeinschaft]] 

EURATOM - [[Europäische Atomgemeinschaft]]
EWG - [[Europäische Wirtschaftsgemeinschaft]]
	_Ziel: gemeinsamer Binnenmarkt_

EG - [[Europäische Gemeinschaft]]

Luxemburger Kompromiss - Mehrheitsprinzip bei Abstimmungen innerhalb der EG stellt Ende einer langen Krisenzeit dar.

Schengener Abkommen - Gemeinsame Binnengrenzen 

Vertrag von Nizza - 

EWS - [[Europäisches Währungssystem]]  

EP - [[Europäisches Parlament]]

EEA - [[Einheitliche Europäische Akte]]

GASP - [[Gemeinsame Außen- und Sicherheitspolitik]]

EWWU - [[Europäische Wirtschafts- und Währungsunion]]

