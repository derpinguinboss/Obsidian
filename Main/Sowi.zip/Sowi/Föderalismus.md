
Definition
---
- Zusammenschluss von Staaten zu einer Organisationsform
- Macht verteilt auf verschiedene Ebenen


Bezug Deutschland (föderaler Bundesstaat)
---
- Bund und Länder 
	- entscheiden selbstständig in bestimmten Bereichen (festgelegt im GG)
	- haben jeweils eigene [[Legislative]], [[Exekutive]] und [[Judikative]]


Bezug EU
---
Kompetenzerweiterung des [[Europäisches Parlament]] und die Einführung der Mehrheitsentscheidungen im [[Europäischer Rat]], durch die ein einzelnes Land die Entscheidungen nicht mehr blockieren kann.
	-> zunehmende Föderalisierung der [[Europäische Union|Europäischen Union]]
[[Subsidiaritätsprinzip]]
	-> Die Gemeinschaft darf nur dann entscheiden, wenn die Mitgliedsstaaten nicht die alleinige Zuständigkeit haben

