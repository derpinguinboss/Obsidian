

Definition
---
- Starke Regionen als dritte Ebene 
- [[Föderalismus|Föderales]] Ebenen System
- Grundsatz der Bürgernähe


Vorteile
---
- Individuellere Anpassung der politischen Entscheidungen auf regionale Interessen
- Bessere Identifikation/Representation/Meinungsvertretung der Bürger mit getroffenen Entscheidungen
- Effizientere Regionalverwaltung
- Stärkere Autonomie und Kompetenzen in Regionen
- "Demokratischer"?
- Politische Partizipation wird gestärkt


Nachteile
---
- Fehlende einheitliche Definition von Regionen
- Unterschiedliche Entscheidungsbefugnisse; schwer vergleichbar
- Einheitliche Entscheidungsfindung schwierig (auf EU-Ebene) und moegl. langwierig
- Geht das Gemeinschaftsgefühl der EU (o. Nationalstaaten) verloren?
- Schwächung on GASP?
- Regionale Disparitäten?