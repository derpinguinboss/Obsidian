Phase I
---
Quelle: S.148, https://www.ccbuchner.de/_files_media/livebook/5782/

Visionen einer [[Europäische Union]] 

•	__1949: Winston Churchills Vision der Vereinigten Staaten von Europa__
Zuerst soll Deutschland mit Frankreich vereint werden
Kleine Staaten haben genauso großen Einfluss wie große

•	__1980: Jean Monnets Idee Deutschland und Frankreich zu vereinen__
Er sieht als Hindernis für eine Europäische Union Frankreichs Furcht
vor einer deutschen Industriellen Überlegenheit durch die deutsche 
Stahlproduktion. 
Ein Bündnis zwischen den beiden sieht er als potenzielle Lösung und 
Grundlage für eine Europäische Union. Für dieses müsste seiner Meinung 
nach Frankreich von der Diskriminierung befreit werden, um eine stabile
Wirtschaft zu erlangen.


Phase II
---
- Eine gemeinsame EU-Herde erschaffen
- Andere Laender sollen beitreten können
- Fokus auf Wirtschaft; Frankreich und Deutschland hauptsächlich Solidarität fördern


Phase III
---
- [[Europäisches Parlament]] wurde schon gegründet
- [[Europäische Gemeinschaft für Kohle und Stahl]]
- 1960: Name => EU-Parlament
- Angst vor Machtverlusten


Phase IV
---
- Intensive Diskussion über Reformen
- Europäische politische Zusammenarbeit
- Steigerung der Effizienz durch Erweiterung des Parlaments
- Europaeischer Vertrag
- Einführung des Euros


Phase V
---
- Grundlagenvertrag
- Institutionelle Reformation


Phase VI
---
- Brexit
- Viele Neuwahlen


