Pro Argumente
---
Hat das bis heute erfüllt, für was sie nominiert wurde: Frieden, Demokratie und Menschenrechte.


