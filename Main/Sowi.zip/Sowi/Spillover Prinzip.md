
Definition
---
Eine Erfolgreiche Zusammenarbeit in einem Bereich führt zu Erfolgen in verwandten Bereichen


>**Supernationale 'political community'**