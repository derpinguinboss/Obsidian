

Klassischer Funktionalismus
---
- Stärkung der technischen Eliten
- Gemeinsame Wahrnehmung unkontroverser Funktionen


Zentrale Prinzipien
---
- [[Spillover Prinzip]]
- [[Form-follows-function Prinzip]]


Bezug [[Europäische Union]]
---
Internationale Probleme
-> Mehr Integration, internationale Zusammenarbeit
-> Transnationale Lösungen